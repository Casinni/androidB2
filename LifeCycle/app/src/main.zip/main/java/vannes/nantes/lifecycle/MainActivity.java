package vannes.nantes.lifecycle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {


    //TODO definition du nom du tag pour loguer les evenements ->nom de la classe
    private final String TAG="ActivitePrincipale";
    @Override
    //Called when the activity is first created
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //TODO à compléter
        Log.i(TAG, "OnCreate" );
    }
    //The final call you receive before your activity is destroyed.
    protected void onDestroy() {
        super.onDestroy();

        //TODO à compléter
        Log.i(TAG,"OnDestroy");
    }
    //Called when the system is about to start resuming a previous activity
    protected void onPause() {
        super.onPause();

        //TODO à compléter
        Log.i(TAG,"OnPause");
    }
    protected void onStop() {
        super.onStop();

        //TODO à compléter
        Log.i(TAG,"OnStop");
    }
    //Called when the activity will start interacting with the user
    protected void onResume() {
        super.onResume();

        //TODO à compléter
        Log.i(TAG,"OnResume");
    }
    //This method is called before an activity may be killed so that when it comes back some time in the future it can restore its state.
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);

        //TODO à compléter
        Log.i(TAG,"OnsaveInstaneState");
    }
    //This method is called after onStart() when the activity is being re-initialized from a previously saved state
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        //TODO à compléter

        Log.i(TAG, "OnRestoreIntanceState");
    }
    //Called when the activity will start interacting with the user
    protected void onRestart() {
        super.onRestart();

        //TODO à compléter
        Log.i(TAG, "OnRestart");
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.setting:
                return true;
            case R.id.exit:
                    finish();
                return true;
        }
        return true;
    }
}